import uuid
import json
from datetime import datetime
from odoo import models, fields, api, exceptions, _


class L10nSvContingency(models.Model):
    """Modelo para manejar reportes de contingencia DTE"""
    _name = 'l10n_sv.contingency'
    _description = 'Reporte de Contingencia DTE'
    _order = 'create_date desc'
    _rec_name = 'display_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # Campos básicos
    name = fields.Char(
        string='Número de Reporte',
        readonly=True,
        copy=False,
        help='Número consecutivo del reporte de contingencia'
    )
    
    display_name = fields.Char(
        string='Nombre',
        compute='_compute_display_name',
        store=True
    )
    
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('pending', 'Pendiente Envío'),
        ('sent', 'Enviado'),
        ('accepted', 'Aceptado'),
        ('rejected', 'Rechazado'),
        ('error', 'Error')
    ], string='Estado', default='draft', required=True, tracking=True)
    
    # Identificación del reporte
    codigo_generacion = fields.Char(
        string='Código de Generación',
        copy=False,
        help='UUID único para este reporte de contingencia'
    )
    
    fecha_inicio = fields.Datetime(
        string='Fecha/Hora Inicio',
        required=True,
        help='Fecha y hora de inicio de la contingencia'
    )
    
    fecha_fin = fields.Datetime(
        string='Fecha/Hora Fin',
        required=True,
        help='Fecha y hora de fin de la contingencia'
    )
    
    fecha_transmision = fields.Datetime(
        string='Fecha/Hora Transmisión',
        help='Fecha y hora de transmisión del reporte al MH'
    )
    
    # Tipo de contingencia
    tipo_contingencia = fields.Selection([
        ('1', 'Falla del sistema del contribuyente'),
        ('2', 'Falla de conectividad'),
        ('3', 'Mantenimiento programado'),
        ('4', 'Falla del sistema del MH'),
        ('5', 'Otra contingencia')
    ], string='Tipo de Contingencia', required=True)
    
    motivo_contingencia = fields.Text(
        string='Motivo de Contingencia',
        required=True,
        help='Descripción detallada del motivo de la contingencia'
    )
    
    # Responsable
    responsable_nombre = fields.Char(
        string='Nombre del Responsable',
        required=True,
        help='Nombre del responsable del establecimiento'
    )
    
    responsable_tipo_doc = fields.Selection([
        ('36', 'NIT'),
        ('13', 'DUI'),
        ('02', 'Carnet de Residente'),
        ('03', 'Pasaporte'),
        ('37', 'Otro')
    ], string='Tipo Documento Responsable', required=True)
    
    responsable_numero_doc = fields.Char(
        string='Número Documento Responsable',
        required=True,
        help='Número de documento del responsable'
    )
    
    # Documentos incluidos en la contingencia
    document_ids = fields.One2many(
        'l10n_sv.contingency.document',
        'contingency_id',
        string='Documentos en Contingencia'
    )
    
    # JSON generado
    json_content = fields.Text(
        string='JSON Contingencia',
        readonly=True,
        help='JSON del reporte de contingencia generado'
    )
    
    # Respuesta del MH
    response_code = fields.Char(
        string='Código Respuesta MH',
        readonly=True
    )
    
    response_message = fields.Text(
        string='Mensaje Respuesta MH',
        readonly=True
    )
    
    # Relaciones
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company
    )
    
    # Campo comentado temporalmente hasta resolver dependencias circulares
    # api_log_id = fields.Many2one(
    #     'l10n_sv.api.log',
    #     string='Log API',
    #     readonly=True,
    #     help='Log de la comunicación con el MH'
    # )

    @api.depends('name', 'tipo_contingencia', 'fecha_inicio')
    def _compute_display_name(self):
        for record in self:
            if record.name:
                tipo_desc = dict(record._fields['tipo_contingencia'].selection).get(record.tipo_contingencia, '')
                record.display_name = f"{record.name} - {tipo_desc}"
            else:
                record.display_name = 'Nuevo Reporte'

    @api.model
    def create(self, vals):
        if not vals.get('name'):
            vals['name'] = self.env['ir.sequence'].next_by_code('l10n_sv.contingency') or '/'
        if not vals.get('codigo_generacion'):
            vals['codigo_generacion'] = str(uuid.uuid4()).upper()
        return super().create(vals)

    def action_generate_json(self):
        """Genera el JSON del reporte de contingencia"""
        self.ensure_one()
        
        if not self.document_ids:
            raise exceptions.UserError(_('Debe agregar al menos un documento a la contingencia'))
        
        # Obtener datos del emisor desde la compañía
        emisor_data = self._get_emisor_data()
        
        # Generar JSON según esquema v3
        contingency_json = {
            "identificacion": {
                "version": 3,
                "ambiente": self._get_environment(),
                "codigoGeneracion": self.codigo_generacion,
                "fTransmision": self.fecha_transmision.strftime('%Y-%m-%d') if self.fecha_transmision else datetime.now().strftime('%Y-%m-%d'),
                "hTransmision": self.fecha_transmision.strftime('%H:%M:%S') if self.fecha_transmision else datetime.now().strftime('%H:%M:%S')
            },
            "emisor": emisor_data,
            "detalleDTE": self._get_document_details(),
            "motivo": {
                "fInicio": self.fecha_inicio.strftime('%Y-%m-%d'),
                "fFin": self.fecha_fin.strftime('%Y-%m-%d'),
                "hInicio": self.fecha_inicio.strftime('%H:%M:%S'),
                "hFin": self.fecha_fin.strftime('%H:%M:%S'),
                "tipoContingencia": int(self.tipo_contingencia),
                "motivoContingencia": self.motivo_contingencia
            }
        }
        
        self.json_content = json.dumps(contingency_json, indent=4, ensure_ascii=False)
        self.state = 'pending'
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('JSON Generado'),
                'message': _('El JSON del reporte de contingencia ha sido generado exitosamente'),
                'type': 'success'
            }
        }

    def _get_emisor_data(self):
        """Obtiene datos del emisor desde la compañía"""
        company = self.company_id
        
        return {
            "nit": company.vat or '',
            "nombre": company.name,
            "nombreResponsable": self.responsable_nombre,
            "tipoDocResponsable": self.responsable_tipo_doc,
            "numeroDocResponsable": self.responsable_numero_doc,
            "tipoEstablecimiento": company.l10n_sv_tipo_establecimiento or "01",
            "codEstableMH": company.l10n_sv_codigo_establecimiento_mh,
            "codPuntoVenta": company.l10n_sv_codigo_punto_venta,
            "telefono": company.phone or '',
            "correo": company.email or ''
        }

    def _get_document_details(self):
        """Obtiene detalles de documentos en contingencia"""
        details = []
        for i, doc in enumerate(self.document_ids, 1):
            details.append({
                "noItem": i,
                "codigoGeneracion": doc.codigo_generacion,
                "tipoDoc": doc.tipo_documento
            })
        return details

    def _get_environment(self):
        """Determina el ambiente (certificación/producción)"""
        # Implementar lógica para determinar ambiente
        # Por ahora retornamos certificación
        return "00"

    def action_send_to_mh(self):
        """Envía el reporte de contingencia al MH"""
        self.ensure_one()
        
        if not self.json_content:
            raise exceptions.UserError(_('Debe generar el JSON antes de enviar'))
        
        # Implementar envío usando l10n_sv_api_client
        try:
            # Aquí se implementaría la llamada al API del MH
            # usando el módulo l10n_sv_api_client
            
            self.state = 'sent'
            self.fecha_transmision = datetime.now()
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Reporte Enviado'),
                    'message': _('El reporte de contingencia ha sido enviado al MH'),
                    'type': 'success'
                }
            }
            
        except Exception as e:
            self.state = 'error'
            raise exceptions.UserError(_('Error al enviar: %s') % str(e))

    def action_view_json(self):
        """Acción para visualizar el JSON generado"""
        self.ensure_one()
        
        if not self.json_content:
            raise exceptions.UserError(_('No hay JSON generado'))
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('JSON Reporte Contingencia'),
            'res_model': 'l10n_sv.json.preview.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_json_content': self.json_content,
                'default_document_type': 'Reporte de Contingencia',
                'default_numero_control': self.name
            }
        }


class L10nSvContingencyDocument(models.Model):
    """Documentos incluidos en un reporte de contingencia"""
    _name = 'l10n_sv.contingency.document'
    _description = 'Documento en Contingencia'
    _order = 'sequence, id'

    sequence = fields.Integer(string='Secuencia', default=10)
    
    contingency_id = fields.Many2one(
        'l10n_sv.contingency',
        string='Reporte Contingencia',
        required=True,
        ondelete='cascade'
    )
    
    move_id = fields.Many2one(
        'account.move',
        string='Documento Contable',
        help='Documento contable relacionado (opcional)'
    )
    
    codigo_generacion = fields.Char(
        string='Código de Generación',
        required=True,
        help='UUID del documento en contingencia'
    )
    
    tipo_documento = fields.Selection([
        ('01', 'Factura'),
        ('03', 'Comprobante de Crédito Fiscal'),
        ('04', 'Nota de Remisión'),
        ('05', 'Nota de Crédito'),
        ('06', 'Nota de Débito'),
        ('07', 'Comprobante de Retención'),
        ('08', 'Comprobante de Liquidación'),
        ('09', 'Documento Contable de Liquidación'),
        ('11', 'Factura de Exportación'),
        ('14', 'Factura de Sujeto Excluido'),
        ('15', 'Comprobante de Donación')
    ], string='Tipo de Documento', required=True)
    
    numero_control = fields.Char(
        string='Número de Control',
        help='Número de control del documento'
    )
    
    fecha_emision = fields.Date(
        string='Fecha Emisión',
        help='Fecha de emisión del documento'
    )
    
    observaciones = fields.Text(
        string='Observaciones',
        help='Observaciones adicionales sobre este documento'
    )

    @api.onchange('move_id')
    def _onchange_move_id(self):
        """Autocompleta campos desde el documento contable"""
        if self.move_id:
            self.codigo_generacion = self.move_id.l10n_sv_edi_codigo_generacion or ''
            self.numero_control = self.move_id.l10n_sv_edi_numero_control or ''
            self.fecha_emision = self.move_id.invoice_date or self.move_id.date
            
            # Determinar tipo de documento
            if hasattr(self.move_id, 'l10n_sv_document_type_id') and self.move_id.l10n_sv_document_type_id:
                self.tipo_documento = self.move_id.l10n_sv_document_type_id.code