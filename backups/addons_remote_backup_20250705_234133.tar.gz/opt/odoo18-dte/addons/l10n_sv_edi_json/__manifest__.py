{
    'name': 'El Salvador - Generador de JSON DTE',
    'version': '18.0.1.0.0',
    'summary': 'Generador de JSON para documentos tributarios electrónicos de El Salvador',
    'description': '''
        Módulo para generar documentos tributarios electrónicos (DTE) en formato JSON
        según las especificaciones técnicas del Ministerio de Hacienda de El Salvador.
        
        Funcionalidades:
        * Generación de JSON DTE para todos los tipos de documentos
        * Integración completa con catálogos del MH (UOM, Payment, Incoterms, etc.)
        * Cálculo automático de totales y clasificación fiscal
        * Validación de estructura JSON según esquemas oficiales
        * Conversión de números a letras según formato MH
        * Preview y validación de JSON antes del envío
        * Soporte para contingencias y documentos relacionados
        * Manejo de contingencias DTE (reportes al MH)
        * Sistema de anulaciones e invalidaciones DTE
        * Templates JSON actualizados a esquemas v3 oficiales
    ''',
    'category': 'Accounting/Localizations/EDI',
    'author': 'Divergentes Media S.A.S. de C.V.',
    'website': 'https://www.divergentesmedia.com',
    'maintainer': 'Divergentes Media S.A.S. de C.V.',
    'support': 'info@divergentesmedia.com',
    'license': 'LGPL-3',
    'depends': [
        'mail',                    # Para chatter y actividades
        'l10n_sv_edi_base',        # Infraestructura EDI base
        'l10n_sv_document_type',   # Tipos de documentos
        'l10n_sv_cta',             # Plan de cuentas e impuestos
        'l10n_latam_sv',           # Tipos de identificación
        'l10n_sv_city',            # Municipios y departamentos
        'l10n_sv_uom',             # Unidades de medida
        'l10n_sv_payment',         # Términos de pago
        'l10n_sv_incoterms',       # Incoterms para exportación
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'data/json_template_data.xml',
        'views/json_generator_views.xml',
        'views/contingency_views.xml',
        'views/cancellation_views.xml',
        'views/account_move_views.xml',
        'views/menu_views.xml',
        'wizard/json_preview_wizard_views.xml',
    ],
    'demo': [
        'demo/demo_data.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}