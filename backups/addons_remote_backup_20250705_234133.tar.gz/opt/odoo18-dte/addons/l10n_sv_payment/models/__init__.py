# -*- coding: utf-8 -*-
from . import account_payment_term
from . import account_payment_method_line