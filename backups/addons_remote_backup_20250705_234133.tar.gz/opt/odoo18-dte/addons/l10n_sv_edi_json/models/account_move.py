import json
import logging
from odoo import models, fields, api, exceptions, _

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    """Extensión de facturas para generación de JSON DTE"""
    _inherit = 'account.move'

    l10n_sv_json_dte = fields.Text(
        string='JSON DTE',
        readonly=True,
        help='JSON del documento tributario electrónico generado'
    )
    
    l10n_sv_json_generator_id = fields.Many2one(
        'l10n_sv.json.generator',
        string='Generador JSON',
        readonly=True,
        help='Generador utilizado para crear el JSON DTE'
    )
    
    l10n_sv_json_generated = fields.Boolean(
        string='JSON Generado',
        readonly=True,
        default=False,
        help='Indica si el JSON DTE ha sido generado'
    )
    
    l10n_sv_json_validated = fields.Boolean(
        string='JSON Validado',
        readonly=True,
        default=False,
        help='Indica si el JSON DTE ha sido validado exitosamente'
    )
    
    l10n_sv_json_errors = fields.Text(
        string='Errores de Validación JSON',
        readonly=True,
        help='Errores encontrados durante la validación del JSON'
    )

    def action_generate_json_dte(self):
        """Acción para generar JSON DTE"""
        self.ensure_one()
        
        if not self.l10n_sv_document_type_id:
            raise exceptions.UserError(_('Debe asignar un tipo de documento DTE a la factura'))
        
        if not self.l10n_sv_edi_numero_control:
            raise exceptions.UserError(_('Debe generar el número de control DTE antes de crear el JSON'))
        
        # Buscar generador apropiado
        generator = self.env['l10n_sv.json.generator'].search([
            ('document_type_id', '=', self.l10n_sv_document_type_id.id),
            ('active', '=', True)
        ], limit=1)
        
        if not generator:
            raise exceptions.UserError(_(
                'No se encontró un generador JSON para el tipo de documento %s'
            ) % self.l10n_sv_document_type_id.name)
        
        try:
            # Generar JSON
            json_data = generator.generate_json_dte(self.id)
            
            # Log temporal para depuración
            if self.l10n_sv_document_type_id.code == '03':
                _logger.info("JSON generado para CCF antes de formatear:")
                _logger.info(f"Tiene codTributo en items: {'codTributo' in json_data.get('cuerpoDocumento', [{}])[0]}")
                _logger.info(f"Tiene ivaItem en items: {'ivaItem' in json_data.get('cuerpoDocumento', [{}])[0]}")
                _logger.info(f"Tiene pagos en resumen: {'pagos' in json_data.get('resumen', {})}")
                _logger.info(f"Tiene numPagoElectronico en resumen: {'numPagoElectronico' in json_data.get('resumen', {})}")
                _logger.info(f"Extension: {json_data.get('extension')}")
            
            # Validar JSON
            generator.validate_json(json_data, self)
            
            # Formatear para almacenamiento
            document_type_code = self.l10n_sv_document_type_id.code if self.l10n_sv_document_type_id else "01"
            formatted_json = generator.format_json_output(json_data, document_type_code)
            
            # Actualizar factura
            self.write({
                'l10n_sv_json_dte': formatted_json,
                'l10n_sv_json_generator_id': generator.id,
                'l10n_sv_json_generated': True,
                'l10n_sv_json_validated': True,
                'l10n_sv_json_errors': False
            })
            
            _logger.info(f'JSON DTE generado exitosamente para factura {self.name}')
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('JSON DTE Generado'),
                    'message': _('El JSON DTE se ha generado correctamente'),
                    'type': 'success'
                }
            }
            
        except Exception as e:
            error_msg = str(e)
            self.write({
                'l10n_sv_json_generated': False,
                'l10n_sv_json_validated': False,
                'l10n_sv_json_errors': error_msg
            })
            
            _logger.error(f'Error generando JSON DTE para factura {self.name}: {error_msg}')
            
            raise exceptions.UserError(_(
                'Error al generar JSON DTE:\n%s'
            ) % error_msg)

    def action_preview_json_dte(self):
        """Acción para previsualizar JSON DTE"""
        self.ensure_one()
        
        if not self.l10n_sv_json_generated:
            self.action_generate_json_dte()
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Vista Previa JSON DTE'),
            'res_model': 'l10n_sv.json.preview.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_move_id': self.id,
                'default_json_content': self.l10n_sv_json_dte
            }
        }

    def action_regenerate_json_dte(self):
        """Acción para regenerar JSON DTE"""
        self.ensure_one()
        
        # Limpiar JSON actual
        self.write({
            'l10n_sv_json_dte': False,
            'l10n_sv_json_generated': False,
            'l10n_sv_json_validated': False,
            'l10n_sv_json_errors': False
        })
        
        # Generar nuevo JSON
        return self.action_generate_json_dte()

    def action_validate_json_dte(self):
        """Acción para validar JSON DTE existente"""
        self.ensure_one()
        
        if not self.l10n_sv_json_dte:
            raise exceptions.UserError(_('No hay JSON DTE para validar'))
        
        try:
            # Parsear JSON
            json_data = json.loads(self.l10n_sv_json_dte)
            
            # Validar con el generador
            if self.l10n_sv_json_generator_id:
                self.l10n_sv_json_generator_id.validate_json(json_data, self)
            
            self.write({
                'l10n_sv_json_validated': True,
                'l10n_sv_json_errors': False
            })
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Validación Exitosa'),
                    'message': _('El JSON DTE es válido'),
                    'type': 'success'
                }
            }
            
        except Exception as e:
            error_msg = str(e)
            self.write({
                'l10n_sv_json_validated': False,
                'l10n_sv_json_errors': error_msg
            })
            
            raise exceptions.UserError(_(
                'Error validando JSON DTE:\n%s'
            ) % error_msg)

    def action_regenerate_json_dte(self):
        """Acción para regenerar JSON DTE"""
        self.ensure_one()
        
        # Limpiar datos previos
        self.write({
            'l10n_sv_json_dte': False,
            'l10n_sv_json_generator_id': False,
            'l10n_sv_json_generated': False,
            'l10n_sv_json_validated': False,
            'l10n_sv_json_errors': False
        })
        
        # Generar nuevamente
        return self.action_generate_json_dte()

    def get_json_dte_dict(self):
        """Retorna el JSON DTE como diccionario Python"""
        self.ensure_one()
        
        if not self.l10n_sv_json_dte:
            return {}
        
        try:
            return json.loads(self.l10n_sv_json_dte)
        except json.JSONDecodeError:
            return {}

    @api.model
    def _get_moves_pending_json_generation(self):
        """Retorna facturas pendientes de generación JSON"""
        return self.search([
            ('move_type', 'in', ['out_invoice', 'out_refund']),
            ('state', '=', 'posted'),
            ('l10n_sv_document_type_id', '!=', False),
            ('l10n_sv_edi_numero_control', '!=', False),
            ('l10n_sv_json_generated', '=', False)
        ])

    def cron_generate_pending_json_dte(self):
        """Tarea programada para generar JSON DTE pendientes"""
        pending_moves = self._get_moves_pending_json_generation()
        
        success_count = 0
        error_count = 0
        
        for move in pending_moves:
            try:
                move.action_generate_json_dte()
                success_count += 1
            except Exception as e:
                error_count += 1
                _logger.error(f'Error en generación automática JSON DTE para factura {move.name}: {str(e)}')
        
        _logger.info(f'Generación automática JSON DTE completada: {success_count} exitosos, {error_count} errores')

    @api.depends('l10n_sv_json_generated', 'l10n_sv_json_validated')
    def _compute_edi_status(self):
        """Computa estado EDI incluyendo JSON"""
        super()._compute_edi_status()
        
        for move in self:
            if move.l10n_sv_json_generated and move.l10n_sv_json_validated:
                if move.l10n_sv_edi_status == 'ready':
                    move.l10n_sv_edi_status = 'json_ready'

    def write(self, vals):
        """Override para regenerar JSON si cambian datos relevantes"""
        result = super().write(vals)
        
        # Campos que requieren regeneración de JSON
        sensitive_fields = [
            'invoice_line_ids',
            'partner_id',
            'l10n_sv_document_type_id',
            'currency_id',
            'invoice_payment_term_id',
            'amount_total'
        ]
        
        if any(field in vals for field in sensitive_fields):
            json_moves = self.filtered(lambda m: m.l10n_sv_json_generated and m.state == 'posted')
            if json_moves:
                json_moves.write({
                    'l10n_sv_json_validated': False,
                    'l10n_sv_json_errors': _('JSON requiere regeneración debido a cambios en la factura')
                })
        
        return result