from . import edi_certificate
from . import edi_configuration
from . import res_company
from . import account_move